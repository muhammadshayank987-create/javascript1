function table() {
    var num = Number(prompt("Enter number:"));
    var range = Number(prompt("Enter range:"));

    for (var i = 1; i <= range; i++) {
        console.log(num + " x " + i + " = " + (num * i));
    }
}