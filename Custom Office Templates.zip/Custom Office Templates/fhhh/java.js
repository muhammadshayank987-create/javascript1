function findCity() {

    var cities = ["Karachi", "Lahore", "Islamabad", "Peshawar"];
    var city = prompt("Enter city:");

    if (city == "Karachi" || city == "Lahore" || city == "Islamabad" || city == "Peshawar") {
        alert("City found!");
    } else {
        alert("City not found!");
    }
}
